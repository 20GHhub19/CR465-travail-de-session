# Grille de correction — format tableau

| Critère | Ce qui est évalué | Excellent | Satisfaisant | Fragile | Insuffisant | Points |
|---|---|---|---|---|---|---:|
| VM as Code avec cloud-init | Présence d’un vrai fichier cloud-init, utilité réelle, automatisation de l’utilisateur, SSH, mises à jour, Docker, préparation de l’hôte | Cloud-init complet, clair, reproductible, réellement utile au déploiement | Cloud-init pertinent mais partiellement incomplet ou peu expliqué | Cloud-init minimal, partiel ou surtout décoratif | Absence de vrai cloud-init ou usage non démontré | 5 |
| Architecture et schéma | Lisibilité, cohérence, zones de confiance, flux, exposition, parcours métier | Schéma clair, complet, juste et aligné avec le déploiement réel | Schéma généralement bon, avec quelques oublis mineurs | Schéma partiel, ambigu ou difficile à relier à la solution | Schéma absent ou incorrect | 5 |
| Déploiement conteneurisé | Qualité de la stack Docker Compose, structure, dépendances, reproductibilité | Stack fonctionnelle, propre, stable et bien structurée | Stack presque complète avec quelques imprécisions mineures | Stack partiellement fonctionnelle ou difficile à reproduire | Solution non déployable ou incohérente | 4 |
| Sécurité des images | Versions explicites, choix d’images, scan ou validation, provenance | Images bien choisies, versions explicites, scan ou justification convaincante | Bonnes pratiques visibles mais démonstration incomplète | Peu d’éléments de sécurité ou choix peu justifiés | Aucune preuve sérieuse de réflexion sur les images | 4 |
| Sécurité à l’exécution | Non-root, absence de mode privilégié, réduction des privilèges, options de sécurité, montages prudents, ressources | Bonnes pratiques visibles, expliquées et majoritairement appliquées | Plusieurs contrôles corrects, quelques écarts justifiés | Sécurité partielle ou surtout déclarative | Presque aucun durcissement réel | 5 |
| Segmentation réseau | Réseaux d’exposition, applicatifs, données, exposition minimale, flux justifiés | Segmentation claire, bien pensée et bien expliquée | Segmentation présente mais perfectible | Segmentation minimale ou peu cohérente | Réseau plat ou services sensibles exposés inutilement | 4 |
| Intégration Drupal Commerce → n8n → Moodle | Cohérence du parcours métier, vente, automatisation, attribution d’accès, démonstration | Flux cohérent, démontré, compréhensible et bien documenté | Flux présent mais partiellement simulé ou incomplet | Logique annoncée mais peu démontrée | Aucune intégration crédible entre les composants | 4 |
| IAM et SSO | Keycloak, SSO Moodle, compréhension des flux d’authentification | SSO fonctionnel, bien démontré et bien expliqué | SSO partiellement fonctionnel ou démonstration incomplète | Configuration présente mais peu convaincante | Absence de mise en œuvre réelle | 4 |
| Reverse proxy et WAF | Rôle de Traefik, rôle d’OpenAppSec, centralisation de l’exposition | Proxy et WAF intégrés et correctement expliqués | Présence partielle ou démonstration limitée | Compréhension faible, intégration incomplète | Absence ou incompréhension manifeste | 2 |
| Observabilité et exploitation | Usage de Portainer CE, états des conteneurs, journaux, diagnostic, éventuellement Grafana/Loki | Portainer CE opérationnel et utilisé intelligemment; diagnostic crédible montré | Portainer présent et exploité partiellement | Portainer peu exploité ou démonstration faible | Aucun usage pédagogique réel de l’observabilité | 2 |
| Qualité des livrables | Vidéo M365 conforme, GitBook, GitHub, document Word/PPT, cohérence globale | Tous les livrables sont complets, cohérents, clairs et professionnels | Très bons livrables avec quelques défauts mineurs | Livrables présents mais inégaux ou difficiles à exploiter | Plusieurs livrables absents, non accessibles ou de faible qualité | 5 |
| **Total** |  |  |  |  |  | **40** |

## Vérifications éliminatoires ou pénalités majeures

| Situation observée | Effet recommandé sur la correction |
|---|---|
| Secrets réels dans GitHub | Pénalité majeure; peut affecter sécurité des images, sécurité à l’exécution et qualité globale |
| Conteneur privilégié sans justification sérieuse | Pénalité majeure sur la sécurité à l’exécution |
| PostgreSQL, Redis, n8n ou interface d’administration sensible exposés publiquement | Pénalité majeure sur la segmentation réseau et l’architecture |
| Absence réelle de cloud-init | Échec partiel ou total du critère VM as Code |
| Vidéo au-delà de 15 min 59 s | Pénalité automatique sur la qualité des livrables |
| Dépôt GitHub inutilisable | Pénalité sur déploiement et qualité des livrables |

## Feuille de pointage par équipe

| Équipe | VM as Code /5 | Architecture /5 | Déploiement /4 | Images /4 | Exécution /5 | Réseaux /4 | Intégration /4 | IAM/SSO /4 | Proxy/WAF /2 | Observabilité /2 | Livrables /5 | Total /40 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|  |  |  |  |  |  |  |  |  |  |  |  |  |

## Références de correction

Les critères de sécurité à l’exécution et de moindre privilège s’alignent avec les recommandations OWASP sur les conteneurs, qui insistent notamment sur l’exécution sans privilèges élevés et la réduction de surface d’attaque.[cite:10][cite:86]

L’usage de Portainer CE comme appui à la démonstration d’exploitation et de consultation des journaux est cohérent avec sa documentation d’utilisation des conteneurs et des logs.[cite:38][cite:87][cite:90]

La faisabilité d’une intégration pédagogique entre n8n et Moodle est compatible avec les capacités de services web et d’API externes de Moodle, ce qui soutient la logique du critère d’intégration fonctionnelle.[cite:62][cite:88][cite:91]
